
// ===== INITIALIZE MENU ON PAGE LOAD =====
document.addEventListener('DOMContentLoaded', function() {
  let page = window.location.pathname;
  
  if(page.includes("menu")) {
    renderMenu();
  }

  if(page.includes("history")) {
    renderOrderHistory();
  }
});

const API_BASE_URL = "http://localhost:3000";

// ===== RENDER MENU WITH CATEGORIES =====
function renderMenu() {
  const categoriesContainer = document.getElementById('menu-categories');
  if(!categoriesContainer) return;
  
  // Group items by category
  const categories = {};
  menuData.forEach(item => {
    if(!categories[item.category]) {
      categories[item.category] = [];
    }
    categories[item.category].push(item);
  });
  
  // Define category order
  const categoryOrder = ['Starters', 'Main Course', 'Burgers', 'Pizza', 'Pasta', 'Salads', 'Desserts', 'Beverages'];
  
  // Render each category
  let html = '';
  categoryOrder.forEach(categoryName => {
    if(categories[categoryName]) {
      const limitedItems = categories[categoryName].slice(0, 3);
      html += `
        <div class="menu-category">
          <h2 class="category-title">${categoryName}</h2>
          <div class="food-grid">
            ${limitedItems.map(item => createFoodCard(item)).join('')}
          </div>
        </div>
      `;
    }
  });
  
  categoriesContainer.innerHTML = html;
}

// ===== CREATE INDIVIDUAL FOOD CARD =====
function createFoodCard(item) {
  let tags = '';
  
  // Add veg/non-veg tag
  if(item.tag === 'veg') {
    tags += '<span class="tag tag-veg">🌱 Vegetarian</span>';
  } else if(item.tag === 'non-veg') {
    tags += '<span class="tag tag-non-veg">🍗 Non-Veg</span>';
  }
  
  // Add special tag
  if(item.special) {
    tags += '<span class="tag tag-special">⭐ Chef\'s Special</span>';
  }
  
  return `
    <div class="food-card">
      <img src="${item.image}" alt="${item.name}" class="food-card-image" onerror="this.src='https://via.placeholder.com/280x220?text=${item.name}'">
      <div class="food-card-content">
        <div class="food-card-header">
          <h3 class="food-card-title">${item.name}</h3>
          <span class="food-card-price">₹${item.price}</span>
        </div>
        <div class="food-card-tags">
          ${tags}
        </div>
        <p class="food-card-description">${item.description}</p>
        <button class="food-card-button" onclick="selectFood('${item.name.replace(/'/g, "\\'")}', ${item.price}, ${item.id})">
          + Add to Cart
        </button>
      </div>
    </div>
  `;
}

// ===== START ORDER =====
function startOrder(){
  let customer = document.getElementById("customer").value;
  let tableNo = document.getElementById("tableNo").value;
  
  if(customer == ""){
    alert("Enter Customer Name");
    return;
  }
  
  localStorage.setItem("customerName", customer);
  localStorage.setItem("tableNo", tableNo);
  localStorage.setItem("orderItems", JSON.stringify([]));
  localStorage.removeItem("total");
  localStorage.removeItem("grand");
  localStorage.removeItem("savedOrderId");
  window.location.href = "./menu.html";
}

// ===== SELECT FOOD AND ADD TO CART =====
// ===== SELECT FOOD AND ADD TO CART =====

function selectFood(name, price, itemId){


  let items =
  JSON.parse(localStorage.getItem("orderItems")) || [];


  // checking item already exists

  let existingItem =
  items.find(
    item => item.id === itemId
  );


  // UPDATE quantity

  if(existingItem){


    existingItem.quantity++;


    existingItem.total =
    existingItem.quantity *
    existingItem.price;


  }


  // CREATE new item

  else{


    items.push({

      id:itemId,

      name:name,

      quantity:1,

      price:price,

      total:price

    });


  }


  localStorage.setItem(
    "orderItems",
    JSON.stringify(items)
  );


  alert(name + " Added to Cart");


}

// ===== GO TO CART =====
function goToCart(){
  window.location.href = "./cart.html";
}

// ===== HANDLE CART PAGE =====
let page = window.location.pathname;

function getOrderItems() {
  return JSON.parse(localStorage.getItem("orderItems")) || [];
}

function getSubtotal(items) {
  return items.reduce((sum, item) => sum + Number(item.total || 0), 0);
}

// ===== DISPLAY CART =====

if(page.includes("cart")){
   displayCart();
}



function displayCart(){


let items = getOrderItems();


let output = "";


let subtotal = 0;



if(items.length === 0){


document.getElementById("summary").innerHTML =
"<h2>Your Cart Is Empty 🛒</h2>";


localStorage.setItem("total",0);


return;

}



items.forEach((item,index)=>{


subtotal += item.total;



output += `


<div class="cart-item">


<h2>${item.name}</h2>


<p>Price : ₹${item.price}</p>


<p>Quantity : ${item.quantity}</p>


<p>Total : ₹${item.total}</p>



<button onclick="removeCartItem(${index})">


Remove Item ❌


</button>


</div>


`;


});
output += `

<h2>

Subtotal : ₹${subtotal}

</h2>


<button onclick="updateOrder()">

Update Order 🍽️

</button>

`;




document.getElementById("summary").innerHTML = output;



localStorage.setItem("total",subtotal);


}
function removeCartItem(index){


let items =
JSON.parse(localStorage.getItem("orderItems")) || [];



items.splice(index,1);



localStorage.setItem(

"orderItems",

JSON.stringify(items)

);



alert("Item Removed ❌");



displayCart();


}

// ===== VOID ITEM =====
function voidItem(){
  localStorage.setItem("orderItems", JSON.stringify([]));
  alert("Order Voided");
  location.reload();
}

// ===== GENERATE BILL =====
function generateBill(){
  window.location.href = "./bill.html";
}

// ===== HANDLE BILL PAGE =====
if(page.includes("bill")){
  let subtotal = Number(localStorage.getItem("total"));
  if(!subtotal) {
    subtotal = getSubtotal(getOrderItems());
  }
  localStorage.setItem("total", subtotal);
  
  let gst = subtotal * 0.05;
  let service = subtotal * 0.10;
  
  let grand = subtotal + gst + service;
  
  localStorage.setItem("grand", grand);
  
  document.getElementById("bill").innerHTML = `
    Subtotal : ₹${subtotal.toFixed(2)}<br>
    GST 5% : ₹${gst.toFixed(2)}<br>
    Service Charge 10% : ₹${service.toFixed(2)}<br>
    Grand Total : ₹${grand.toFixed(2)}
  `;

  saveOrderToBackend();
}

function splitBill(){
  let persons = Number(document.getElementById("persons").value);
  let grand = Number(localStorage.getItem("grand"));
  let splitOutput = document.getElementById("split");

  if(!persons || persons <= 0) {
    splitOutput.innerHTML = "Please enter a valid number of persons.";
    return;
  }

  if(!grand) {
    splitOutput.innerHTML = "Bill total not available yet. Please generate the bill first.";
    return;
  }

  splitOutput.innerHTML = "Each Person Pays : ₹" + (grand / persons).toFixed(2);
}

async function saveOrderToBackend(){
  if(localStorage.getItem("savedOrderId")) {
    return;
  }

  const items = getOrderItems();

  if(items.length === 0) {
    const billStatus = document.getElementById("split");
    if(billStatus) {
      billStatus.innerHTML = "No items available to save.";
    }
    return;
  }

  const payload = {
    customerName: localStorage.getItem("customerName") || "",
    tableNo: localStorage.getItem("tableNo") || "",
    items: items
  };

  try {
    const response = await fetch("http://localhost:3000/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if(!response.ok) {
      throw new Error(data.message || "Unable to save order");
    }

    localStorage.setItem("savedOrderId", String(data.id));

    const statusBox = document.getElementById("split");
    if(statusBox) {
      statusBox.innerHTML = `Order saved to backend. Order ID: ${data.id}`;
    }
  } catch (error) {
    const statusBox = document.getElementById("split");
    if(statusBox) {
      statusBox.innerHTML = `Backend save failed: ${error.message}`;
    }
  }
}

async function renderOrderHistory() {
  const historyList = document.getElementById("history-list");
  const historyTitle = document.getElementById("history-title");
  const historyMeta = document.getElementById("history-meta");
  const historySummary = document.getElementById("history-summary");
  const historyItems = document.getElementById("history-items");

  if (!historyList || !historyTitle || !historyMeta || !historySummary || !historyItems) {
    return;
  }

  const clearDetail = () => {
    historyTitle.textContent = "Select an order";
    historyMeta.textContent = "Choose an order from the left panel to view its items and totals.";
    historySummary.innerHTML = "";
    historyItems.innerHTML = `<tr><td colspan="5" class="history-empty">No order selected</td></tr>`;
  };

  const renderOrderDetail = (order) => {
    historyTitle.textContent = `Order #${order.id}`;
    historyMeta.textContent = `${order.customer_name} • Table ${order.table_no || "-"} • ${new Date(order.created_at).toLocaleString()}`;

    historySummary.innerHTML = `
      <div class="history-stat"><span>Subtotal</span><strong>₹${Number(order.subtotal).toFixed(2)}</strong></div>
      <div class="history-stat"><span>GST</span><strong>₹${Number(order.gst).toFixed(2)}</strong></div>
      <div class="history-stat"><span>Service</span><strong>₹${Number(order.service_charge).toFixed(2)}</strong></div>
      <div class="history-stat history-stat-highlight"><span>Grand Total</span><strong>₹${Number(order.grand_total).toFixed(2)}</strong></div>
    `;

    if (!order.items || order.items.length === 0) {
      historyItems.innerHTML = `<tr><td colspan="5" class="history-empty">No items found</td></tr>`;
      return;
    }

    historyItems.innerHTML = order.items.map((item, index) => `
      <tr>
        <td>${index + 1}</td>
        <td>${item.item_name}</td>
        <td>${item.quantity}</td>
        <td>₹${Number(item.price).toFixed(2)}</td>
        <td>₹${Number(item.total).toFixed(2)}</td>
      </tr>
    `).join("");
  };

  try {
    const response = await fetch(`${API_BASE_URL}/orders`);
    const orders = await response.json();

    if (!response.ok) {
      throw new Error(orders.message || "Unable to load order history");
    }

    if (!orders.length) {
      historyList.innerHTML = `<div class="history-empty-panel">No saved orders yet.</div>`;
      clearDetail();
      return;
    }

    historyList.innerHTML = orders.map((order, index) => `
      <button class="history-order-item ${index === 0 ? 'active' : ''}" data-order-id="${order.id}">
        <span class="history-order-top">Order #${order.id}</span>
        <span class="history-order-mid">${order.customer_name}</span>
        <span class="history-order-bot">₹${Number(order.grand_total).toFixed(2)}</span>
      </button>
    `).join("");

    const loadOrder = async (orderId) => {
      const detailResponse = await fetch(`${API_BASE_URL}/orders/${orderId}`);
      const order = await detailResponse.json();

      if (!detailResponse.ok) {
        throw new Error(order.message || "Unable to load order details");
      }

      renderOrderDetail(order);

      document.querySelectorAll('.history-order-item').forEach((button) => {
        button.classList.toggle('active', button.dataset.orderId === String(order.id));
      });
    };

    document.querySelectorAll('.history-order-item').forEach((button) => {
      button.addEventListener('click', () => loadOrder(button.dataset.orderId));
    });

    await loadOrder(orders[0].id);
  } catch (error) {
    historyList.innerHTML = `<div class="history-empty-panel">${error.message}</div>`;
    clearDetail();
  }
}
// ===============================
// UPDATE ORDER
// ===============================

function updateOrder(){

    window.location.href = "./menu.html";


}