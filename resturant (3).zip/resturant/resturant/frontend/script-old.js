

function startOrder(){


let customer=document.getElementById("customer").value;


if(customer==""){

alert("Enter Customer Name");

return;

}


localStorage.setItem(
"orderItems",
JSON.stringify([])
);


window.location.href="./menu.html";


}





function selectFood(name,price){

let qty = 1;

if(confirm("Add Extra Spicy Modifier +₹20?")){

price+=20;

}

let total=price*qty;

let items=JSON.parse(

localStorage.getItem("orderItems")

);

items.push({

name:name,

quantity:qty,

total:total

});

localStorage.setItem(

"orderItems",

JSON.stringify(items)

);

alert(name+" Added");

}







function goToCart(){


window.location.href="./cart.html";


}







let page=window.location.pathname;




if(page.includes("cart")){


let items=JSON.parse(

localStorage.getItem("orderItems")

);



let output="";


let subtotal=0;



items.forEach((item,i)=>{


output+=

`${i+1}. ${item.name}<br>

Qty:${item.quantity}<br>

Amount:₹${item.total}<br><br>`;


subtotal+=item.total;


});



localStorage.setItem(

"total",

subtotal

);



document.getElementById("summary").innerHTML=

output+

"Subtotal : ₹"+subtotal;


}







function voidItem(){


localStorage.setItem(

"orderItems",

JSON.stringify([])

);


alert("Order Voided");


location.reload();


}








function generateBill(){


window.location.href="./bill.html";


}








if(page.includes("bill")){


let subtotal=Number(

localStorage.getItem("total")

);



let gst=subtotal*0.05;


let service=subtotal*0.10;



let grand=subtotal+gst+service;



localStorage.setItem(

"grand",

grand

);



document.getElementById("bill").innerHTML=

`
Subtotal : ₹${subtotal}<br>

GST 5% : ₹${gst}<br>

Service Charge 10% : ₹${service}<br>

Grand Total : ₹${grand}

`;


}








function splitBill(){



let persons=

Number(document.getElementById("persons").value);



let grand=

Number(localStorage.getItem("grand"));



document.getElementById("split").innerHTML=

"Each Person Pays : ₹"

+

(grand/persons).toFixed(2);


}